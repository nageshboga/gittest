package com.mpm.ecom.listprice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListpriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
