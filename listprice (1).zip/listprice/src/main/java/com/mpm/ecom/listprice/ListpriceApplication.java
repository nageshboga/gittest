package com.mpm.ecom.listprice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListpriceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListpriceApplication.class, args);
	}

}
