package com.mpm.ecom.listprice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JapanListPriiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
